import os
import sys

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

# Solana Program IDs
SYSTEM_TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
SYSTEM_ASSOCIATED_TOKEN_ACCOUNT_PROGRAM = "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJAQkn"
PUMP_PROGRAM = "pumpCmGbxz46DXY5X8YWVSGgHqRd37ZrMY5A7mNgBL"

# Solana RPC endpoints
RPC_ENDPOINT = os.getenv("RPC_ENDPOINT", "https://api.mainnet-beta.solana.com")
RPC_URL = os.getenv("RPC_URL", "https://api.mainnet-beta.solana.com")

# DexScreener API endpoints
TOKEN_PROFILE_URL = os.getenv("TOKEN_PROFILE_URL", "https://api.dexscreener.com/token-profiles/latest/v1")
TOKEN_BOOSTS_URL = os.getenv("TOKEN_BOOSTS_URL", "https://api.dexscreener.com/token-boosts/latest/v1")
TOP_BOOSTS_URL = os.getenv("TOP_BOOSTS_URL", "https://api.dexscreener.com/token-boosts/top/v1")
TOKEN_PAIRS_URL_TEMPLATE = os.getenv("TOKEN_PAIRS_URL_TEMPLATE", "https://api.dexscreener.com/search/?q={tokenAddress}")

# Wallet configuration
PRIVATE_KEY = os.getenv("PRIVATE_KEY", "5KCmRVjsY1pira4apxGDWhpWTCkuEjs9io5qzMeNyv5i5T2fxCxKJ6J6bDuTUqrfnLosd4mRkKAYHC3sTbUJnFak")

# Helius API
HELIUS_API_KEY = os.getenv("HELIUS_API_KEY", "113dc31e-3c9b-4b19-bfd8-a6224e9b56e5")

# AI model
AI_MODEL = os.getenv("AI_MODEL", "distilbert-base-uncased-finetuned-sst-2-english")

# Trading parameters
BUY_AMOUNT = float(os.getenv("BUY_AMOUNT", "0.01"))
sell_budget = float(os.getenv("SELL_BUDGET", "0.01"))
BUY_SLIPPAGE = int(os.getenv("BUY_SLIPPAGE", "5"))
SELL_SLIPPAGE = int(os.getenv("SELL_SLIPPAGE", "5"))
stop_loss_percent = float(os.getenv("STOP_LOSS_PERCENT", "5"))
sell_after_seconds = int(os.getenv("SELL_AFTER_SECONDS", "60"))
immediate_profit_threshold = float(os.getenv("IMMEDIATE_PROFIT_THRESHOLD", "2"))
trailing_stop_percent = float(os.getenv("TRAILING_STOP_PERCENT", "3"))

# Trading state
fee_cache = {}
total_gas_cost = 0.0
total_gas_cost_usd = 0.0
total_profit = 0.0
total_profit_usd = 0.0
trade_count = 0
wallet_simulated_balance = 0.0
buy_prices = {}
buy_prices_usd = {}
sell_prices = {}
sell_prices_usd = {}
