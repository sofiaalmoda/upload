<header>
    <div class="holder">
        <div class="left">
            <img src="res/logo-pc.png" class="pc">
            <img src="res/logo-mobile.png" class="mobile">
        </div>
        <div class="right">
            <div class="l">
                <span>Privatkunden</span>
                <span>Unternehmerkunden</span>
                <span>Wealth Management</span>
                <span>Firmenkunden</span>
            </div>
            <div class="r">
                <img src="res/menu-pc.png" class="pc">
                <img src="res/menu-mobile.png" class="mobile">
            </div>
        </div>
    </div>
</header>