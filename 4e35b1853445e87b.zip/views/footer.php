<footer>
<div class="holder">
<div class="social">
    <div class="left"><span>24 Stunden für Sie da.</span></div>
    <div class="right"><img src="res/social.png"></div>
</div>
<div class="logos">
    <div class="left"><img src="res/cm.png"></div>
    <div class="right"><span>Die Bank an Ihrer Seite</span></div>
</div>
<div class="links">
<span>AGB</span>
<span>Rechtliche Hinweise</span>
<span>Impressum</span>
<span>Einwilligungseinstellung</span>
<span>Konzern</span>
<span>Karriere</span>
</div>
</div>
</footer>